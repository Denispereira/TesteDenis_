/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import dao.Usuario;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author CASA
 */
@Path("testeDeWs")
public class TesteDenis {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of TesteDenis
     */
    public TesteDenis() {
    }

    /**
     * Retrieves representation of an instance of ws.TesteDenis
     * @return an instance of java.lang.String
     */
    @GET
    @Produces("application/text")
    public String getJson() {
        //TODO return proper representation object
        return "TesteRest ok, status 200";
    }
    @GET
    @Produces("application/text")
    @Path ("Usuario/get")
    /*public String getUsuario(){
        Usuario u = new Usuario();
        u.setLogin("Maria");
        Gson g = new Gson();
        return g.toJson(u);
}*/
    public String getUsuario(){
        return ("Maria");
    }

    
    
    

   
}
